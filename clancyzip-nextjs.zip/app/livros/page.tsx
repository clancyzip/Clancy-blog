import BookCard from "@/components/BookCard";

const books = [
  { title: "A Arte Sutil de Recaídas", description: "Como parar de pensar e sentir como um desgraçado." },
  { title: "Senhorita Martinez", description: "Vício emocional, caos e redenção em prosa cortante." },
  { title: "Papel Salgado", description: "Melancolia estética e realista embaladas em silêncio." },
];

export default function LivrosPage() {
  return (
    <section className="space-y-6">
      <h1 className="h1">Meus Livros</h1>
      <div className="grid gap-6 md:grid-cols-2">
        {books.map((b) => (
          <BookCard key={b.title} title={b.title} description={b.description} />
        ))}
      </div>
    </section>
  );
}
