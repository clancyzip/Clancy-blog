import Chat from "@/components/Chat";

export const metadata = { title: "Comunidade • clancy.zip" };

export default function ComunidadePage() {
  return (
    <section className="space-y-4">
      <h1 className="h1">Comunidade</h1>
      <p className="text-neutral-400">Chat estilo cosmic-talk — simples, mas vivo.</p>
      <Chat />
    </section>
  );
}
