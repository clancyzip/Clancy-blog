import "./globals.css";
import type { Metadata } from "next";
import Link from "next/link";
import Nav from "@/components/Nav";

export const metadata: Metadata = {
  title: "clancy.zip",
  description: "Um fragmento da Insuficiência Cósmica",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>
        <div className="container py-8">
          <header className="mb-10 flex items-center justify-between">
            <div>
              <Link href="/" className="h1">clancy.zip</Link>
              <p className="text-neutral-400">Um fragmento da Insuficiência Cósmica</p>
            </div>
            <Nav />
          </header>
          <main>{children}</main>
          <footer className="mt-16 text-neutral-500 text-sm">© {new Date().getFullYear()} clancy.zip</footer>
        </div>
      </body>
    </html>
  );
}
