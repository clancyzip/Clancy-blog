export default function SobrePage() {
  return (
    <section className="space-y-4 animate-fadeIn">
      <h1 className="h1">Sobre Clancy</h1>
      <p className="text-neutral-400 leading-relaxed">
        Eu sou Clancy, a versão compactada de mim mesmo — um arquivo .zip cheio de
        pensamentos que explodem quando você tenta abrir. Já fui caos, já fui fé,
        já fui fantasma dentro do meu próprio corpo. Hoje, escrevo como quem
        tenta mapear o universo interno com um lápis quebrado, tropeçando entre
        traumas, epifanias e aquela sensação de estar vivo demais para ignorar,
        mas cansado demais para comemorar.
      </p>
      <p className="text-neutral-400 leading-relaxed">
        Meu blog existe porque minha cabeça não cala. Porque a Insuficiência
        Cósmica é real. Porque às vezes a única forma de sobreviver é transformar
        desespero em texto e silêncio em poesia estranha. Se você está lendo
        isso: bem-vindo ao arquivo corrompido que me fez ser quem sou.
      </p>
    </section>
  );
}
