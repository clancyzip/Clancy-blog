export default function HomePage() {
  const posts = [
    {
      title: "Bem-vindo ao clancy.zip",
      excerpt: "Um blog experimental que mistura caos filosófico, humor existencial e viagens cósmicas da mente.",
    },
    {
      title: "Insuficiência Cósmica e o Arquivo Perdido",
      excerpt: "Como transformar sentimentos bagunçados em arquivos .zip carregados de sentido.",
    },
  ];

  return (
    <div className="grid gap-6 md:grid-cols-2">
      {posts.map((post, i) => (
        <article key={i} className="card animate-fadeIn">
          <h2 className="h2 mb-1">{post.title}</h2>
          <p className="text-neutral-400 mb-4">{post.excerpt}</p>
          <button className="btn">Ler mais</button>
        </article>
      ))}
    </div>
  );
}
