# clancy.zip — Next.js + Tailwind

Blog cósmico e melancólico com páginas: Início, Sobre, Livros e Comunidade (chat local).

## Rodar localmente
```bash
npm install
npm run dev
```

## Publicar na Vercel
1. Crie um repositório no GitHub e envie estes arquivos.
2. No Vercel, clique em New Project → Import Git Repository.
3. Selecione o repositório e deploy.

Feito. 🌌
