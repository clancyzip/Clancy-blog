"use client";
import { useState } from "react";

type Msg = { text: string; time: string };

export default function Chat() {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");

  function send() {
    const text = input.trim();
    if (!text) return;
    setMessages((m) => [...m, { text, time: new Date().toLocaleTimeString() }]);
    setInput("");
  }

  return (
    <div className="space-y-3 animate-fadeIn">
      <div className="card h-80 overflow-y-auto space-y-2">
        {messages.length === 0 && (
          <p className="text-neutral-500">Comece a conversa cósmica...</p>
        )}
        {messages.map((m, i) => (
          <div key={i} className="bg-neutral-800/80 border border-neutral-700 rounded-xl p-3">
            <p className="text-neutral-200">{m.text}</p>
            <span className="text-neutral-500 text-xs">{m.time}</span>
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Digite algo cósmico..."
          className="flex-1 rounded-xl bg-neutral-900 border border-neutral-700 px-3 py-2 outline-none"
        />
        <button onClick={send} className="btn">Enviar</button>
      </div>
    </div>
  );
}
