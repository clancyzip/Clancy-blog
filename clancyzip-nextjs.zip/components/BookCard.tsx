type Props = { title: string; description: string };
export default function BookCard({ title, description }: Props) {
  return (
    <div className="card animate-fadeIn">
      <h3 className="h2 mb-1">{title}</h3>
      <p className="text-neutral-400 mb-4">{description}</p>
      <button className="btn">Ver detalhes</button>
    </div>
  );
}
