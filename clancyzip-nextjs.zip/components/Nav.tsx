"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const links = [
  { href: "/", label: "Início" },
  { href: "/sobre", label: "Sobre" },
  { href: "/livros", label: "Livros" },
  { href: "/comunidade", label: "Comunidade" },
];

export default function Nav() {
  const pathname = usePathname();
  return (
    <nav className="flex gap-4">
      {links.map((l) => {
        const active = pathname === l.href;
        return (
          <Link
            key={l.href}
            href={l.href}
            className={`navlink ${active ? "font-semibold text-white" : ""}`}
          >
            {l.label}
          </Link>
        );
      })}
    </nav>
  );
}
